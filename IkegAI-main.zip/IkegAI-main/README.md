# IkegAI
IkegAI is an AI-based career orientation system inspired by Japanese philosophy. It uses psychological and social tests to build a personal profile and guide long-term professional development.
